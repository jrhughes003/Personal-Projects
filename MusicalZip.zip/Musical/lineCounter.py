import re
from collections import defaultdict

def analyze_gatsby_script(filename="script yuh (Rev 1) (1).txt"):
    """
    Parses the script to match the 'Ground Truth' methodology:
    - Separates Scene Lines from Song Lines.
    - Removes [source] tags.
    - Counts characters (letters) in dialogue per character.
    """
    
    # --- Data Stores ---
    # { 'Scene 1.1': { 'NATE': 100, 'ROSIE': 50 }, ... } (character counts)
    scene_data = defaultdict(lambda: defaultdict(int))
    
    # { 'Song 1': { 'NATE': 100 }, ... } (character counts)
    song_data = defaultdict(lambda: defaultdict(int))
    
    # --- State Variables ---
    current_context_name = "Start" # e.g., "1.1" or "Song 1"
    is_song_mode = False           # True if we are in a song, False if in a scene
    current_speaker = None

    # --- Regex Patterns ---
    
    # 1. Source Tag Removal: Matches ""
    SOURCE_PATTERN = re.compile(r'<[^>]+>')
    
    # 2. Context Headers
    # Matches "Scene 1.1" or "1.1" at start of line
    SCENE_HEADER = re.compile(r'^(?:Scene\s+)?(\d+\.\d+)', re.IGNORECASE)
    # Matches "Song 1" or "Song 2:"
    SONG_HEADER = re.compile(r'^Song\s+(\d+)', re.IGNORECASE)
    
    # 3. Speaker Detection
    # Logic: Look for lines that are UPPERCASE (allowing numbers/dots for 'FIRST YEAR 1')
    # Must be at least 2 chars long.
    # Exclude common non-speaker uppercase words like "INT.", "EXT."
    SPEAKER_PATTERN = re.compile(r'^([A-Z0-9\s\.\-\']+)$')
    
    # Words to ignore if they appear in all caps (not characters)
    IGNORE_KEYWORDS = {"INT.", "EXT.", "THE END", "BLACKOUT", "ACT", "SCENE"}

    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            # --- A. Cleanup ---
            # Remove tags anywhere in the line
            line = SOURCE_PATTERN.sub('', line).strip()
            
            # Skip empty lines
            if not line:
                continue

            # --- B. Context Switching ---
            
            # Check for Scene Header (e.g. "1.1" or "Scene 1.1")
            scene_match = SCENE_HEADER.match(line)
            if scene_match:
                current_context_name = scene_match.group(1) # Just "1.1"
                is_song_mode = False
                current_speaker = None
                continue

            # Check for Song Header (e.g. "Song 2")
            song_match = SONG_HEADER.match(line)
            if song_match:
                current_context_name = f"Song {song_match.group(1)}"
                is_song_mode = True
                current_speaker = None
                continue

            # --- C. Speaker Detection ---
            
            # Check if line is a Speaker Header
            if SPEAKER_PATTERN.match(line):
                # Double check it's not a stage direction or scene header
                if any(keyword in line for keyword in IGNORE_KEYWORDS):
                    current_speaker = None
                    continue
                
                # Check for " - " format (e.g. "RENEESE - STUDENT 1")
                # We usually want the first part as the actor/key
                if " - " in line:
                    clean_name = line.split(" - ")[0].strip()
                else:
                    clean_name = line
                
                current_speaker = clean_name
                continue # Don't count the name itself as a line

            # --- D. Character Counting ---
            
            if current_speaker:
                # Ignore stage directions in parentheses
                if line.startswith('(') or line.endswith(')'):
                    continue
                
                # Ignore stage directions in brackets
                if line.startswith('[') or line.endswith(']'):
                    continue
                
                # If we made it here, it's a valid spoken/sung line!
                # Count the characters (letters, spaces, punctuation) in the line
                char_count = len(line)
                
                if is_song_mode:
                    song_data[current_context_name][current_speaker] += char_count
                else:
                    scene_data[current_context_name][current_speaker] += char_count

    return scene_data, song_data

def print_percentages(scene_data, song_data):
    """Prints percentage of total characters spoken by each character."""
    
    # Combine all character counts from scenes and songs
    total_chars_by_speaker = defaultdict(int)
    
    # Add scene characters
    for scene in scene_data.values():
        for speaker, count in scene.items():
            total_chars_by_speaker[speaker] += count
    
    # Add song characters
    for song in song_data.values():
        for speaker, count in song.items():
            total_chars_by_speaker[speaker] += count
    
    # Calculate total characters in script
    total_chars = sum(total_chars_by_speaker.values())
    
    if total_chars == 0:
        print("No dialogue found in script.")
        return
    
    # Sort by character count (descending)
    sorted_speakers = sorted(total_chars_by_speaker.items(), key=lambda x: x[1], reverse=True)
    
    # Print results
    print("="*60)
    print("🎭 CHARACTER DIALOGUE PERCENTAGES (by character count)")
    print("="*60)
    print(f"{'CHARACTER':<30} | {'CHARS':<10} | {'PERCENTAGE':<10}")
    print("-" * 60)
    
    for speaker, count in sorted_speakers:
        percentage = (count / total_chars) * 100
        print(f"{speaker:<30} | {count:<10} | {percentage:>6.2f}%")
    
    print("-" * 60)
    print(f"{'TOTAL':<30} | {total_chars:<10} | {'100.00%':>10}")
    print("="*60)

# --- Run ---
scene_data, song_data = analyze_gatsby_script()
print_percentages(scene_data, song_data)