import re
from collections import defaultdict
from pypdf import PdfReader # The library to read PDFs

def analyze_hamleng_pdf(filename="HAMLENG_Script_Rev_1.pdf"):
    """
    Reads a PDF file directly, extracts text, and counts PHYSICAL LINES 
    of dialogue for Cast Members and Roles.
    """
    
    print(f"📄 Reading PDF file: {filename}...")

    # --- Dictionaries ---
    cast_member_counts = defaultdict(int)
    role_counts = defaultdict(int)
    scene_role_counts = defaultdict(lambda: defaultdict(int))
    
    current_scene = "PRE-SCRIPT" 

    # --- Configuration Patterns ---
    
    # 1. Heuristic for Names: ALL CAPS, at least 2 letters, no numbers.
    #    This avoids matching page numbers like "1." or "10."
    HEURISTIC_NAME_PATTERN = re.compile(r'^(?=.*[A-Z]{2,})(?!.*[0-9])[A-Z\s\.\,\'-]{3,50}$') 
    
    # 2. Scene Detection: Looks for "Scene X" or "Scene X: Title"
    SCENE_PATTERN = re.compile(r'^Scene\s+(\d+)', re.IGNORECASE)
    
    # 3. Known Collective Roles / Groups (To keep them distinct)
    COLLECTIVE_ROLES = [
        "EVERYONE", "VPs", "AMAZON MINIONS", "ALL MUSICAL MEMBERS", 
        "MUSICAL MEMBERS", "HITBIKERS MEMBER", "HITBIKER GILBERT", 
        "ALL SPECTATORS", "FIRST YEARS", "MAC ENG MUSICAL", "TEAM HEIDI",
        "TEAM LOGAN", "BOTH CLERKS", "STUDENTS"
    ]
    
    # --- Helper Functions ---

    def extract_names(name):
        """Splits 'ACTOR - ROLE' or cleans up 'ROLE'."""
        name = name.replace(":", "").strip()
        
        # Default assumption: Cast Name is the name; Role Name is the name
        cast_name = name
        role_name = name

        # Case A: Hyphenated "Actor - Role" (e.g., "RENEESE - STUDENT 1")
        if '-' in name:
            parts = name.split('-', 1)
            cast_name = parts[0].strip()
            role_name = parts[1].strip()
        
        # Case B: Collective Roles (Keep Cast/Role identical)
        elif any(group in name for group in COLLECTIVE_ROLES):
            cast_name = name
            role_name = name
        
        # Case C: Standard Names (e.g. "HEIDI") - Just ensure we grab the first word as Cast Key if simpler
        else:
            # If it's a simple name like "HEIDI", Cast=HEIDI, Role=HEIDI
            pass 

        # --- Formatting Cleanup / Merging Duplicates ---
        # Normalize specific roles to keep counts clean
        if "STUDENT 1" in role_name: role_name = "STUDENT 1"
        if "STUDENT 2" in role_name: role_name = "STUDENT 2"
        if "STUDENT 3" in role_name: role_name = "STUDENT 3"
        if "STUDENT 4" in role_name: role_name = "STUDENT 4"
        if "ACADEMIC ADVISOR" in role_name: role_name = "ABBY VISOR"
        if role_name.endswith("SARMAMI (MUFENGSA'S GF)"): role_name = "SARMAMI"
        
        # Normalize Cast Members (Merge "RENEESE" and "RENEESE " etc)
        cast_name = cast_name.split(' ')[0] if cast_name not in COLLECTIVE_ROLES and " " in cast_name else cast_name

        return cast_name, role_name

    def is_non_dialogue(line):
        """Filters out stage directions, song cues, and headers."""
        line = line.strip()
        return (line.startswith('(') and line.endswith(')')) or \
               (line.startswith('[') and line.endswith(']')) or \
               line.startswith('*') or \
               line.startswith('--- PAGE') or \
               line.startswith('Act ') or \
               re.match(r'^Song\s+\d', line, re.IGNORECASE) or \
               re.match(r'^(INT\.|EXT\.)', line)

    # --- MAIN PROCESSING LOOP ---
    
    try:
        reader = PdfReader(filename)
        full_text = ""
        
        # Extract text from all pages
        for page in reader.pages:
            full_text += page.extract_text() + "\n"
            
        # Split into lines
        lines = full_text.splitlines()
        
        current_speaker_data = (None, None) # (Cast Name, Role Name)

        for line in lines:
            line = line.strip()
            if not line: 
                current_speaker_data = (None, None) # Reset on blank lines (usually implies end of block)
                continue

            # 1. Check for Scene Change
            scene_match = SCENE_PATTERN.match(line)
            if scene_match:
                current_scene = "Scene " + scene_match.group(1)
                current_speaker_data = (None, None)
                continue

            if is_non_dialogue(line): 
                continue
            
            # 2. Check for Character Name Header
            is_new_speaker = False
            
            # Heuristic: If it looks like a name, treat it as a header
            if HEURISTIC_NAME_PATTERN.match(line):
                # Ignore common false positives like "THE END" or "SCENE"
                if line in ["THE END", "BLACKOUT", "END OF PRANK"]:
                    continue
                    
                cast_name, role_name = extract_names(line)
                current_speaker_data = (cast_name, role_name)
                is_new_speaker = True
            
            # 3. Check for "NAME: Dialogue" on one line
            elif ':' in line:
                 parts = line.split(':', 1)
                 potential_name = parts[0].strip()
                 if HEURISTIC_NAME_PATTERN.match(potential_name):
                    cast_name, role_name = extract_names(potential_name)
                    current_speaker_data = (cast_name, role_name)
                    is_new_speaker = True
                    # If there is dialogue after the colon, we count it immediately
                    if len(parts) > 1 and parts[1].strip():
                        # It's a line!
                        pass
                    else:
                        continue 

            # 4. Count the Line
            # If we have a valid speaker, and this line wasn't just the name header itself
            if current_speaker_data[0] is not None and current_scene != "PRE-SCRIPT" and not is_new_speaker:
                cast_name, role_name = current_speaker_data
                
                # INCREMENT COUNT (1 Line)
                cast_member_counts[cast_name] += 1
                role_counts[role_name] += 1
                scene_role_counts[current_scene][role_name] += 1

    except FileNotFoundError:
        print(f"❌ Error: File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ An error occurred: {e}")
        return

    # --- PRINT RESULTS ---
    
    total_lines = sum(role_counts.values())
    
    print("\n" + "="*60)
    print("🎭  PDF SCRIPT LINE COUNT ANALYSIS  🎭")
    print("="*60)
    print(f"Total Lines Counted: {total_lines:,}")
    
    print("\n------------------------------------------------------------")
    print(f"{'CAST MEMBER':<25}{'LINES':>10}{'% OF TOTAL':>15}")
    print("------------------------------------------------------------")
    
    for cast, count in sorted(cast_member_counts.items(), key=lambda x: x[1], reverse=True):
        if count > 5: # Filter out tiny noise
            perc = (count / total_lines) * 100
            print(f"{cast:<25}{count:>10,}{perc:>14.1f}%")

    print("\n" + "="*60)
    print("🎬  SCENE BREAKDOWN (By Role)")
    print("="*60)
    
    # Sort scenes naturally (Scene 1, Scene 2...)
    def natural_sort_key(s):
        return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]
    
    sorted_scenes = sorted(scene_role_counts.keys(), key=natural_sort_key)
    sorted_roles = sorted([r for r in role_counts.keys() if role_counts[r] > 10]) # Major roles only

    # Header
    header = f"{'ROLE':<15}"
    for s in sorted_scenes:
        short_s = s.replace("Scene ", "S")
        header += f"{short_s:>6}"
    header += f"{'TOT':>6}"
    print(header)
    print("-" * len(header))

    # Rows
    for role in sorted_roles:
        row = f"{role:<15}"
        total_role = 0
        for scene in sorted_scenes:
            val = scene_role_counts[scene].get(role, 0)
            total_role += val
            row += f"{val:>6}" if val > 0 else f"{'-':>6}"
        row += f"{total_role:>6}"
        print(row)

# --- RUN THE FUNCTION ---
# Make sure your PDF file name matches this exactly!
analyze_hamleng_pdf("HAMLENG_Script_Rev_1.pdf")